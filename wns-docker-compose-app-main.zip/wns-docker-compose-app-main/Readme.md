# Quest 1729

Launch the app with the following command: `docker-compose -f docker-compose.dev.yml up --build`
